# Recursos de terceros

- **Kenney «Pixel UI»** (`assets/pixel/kenney-pixel-ui`): CC0 — ver `assets/pixel/kenney-pixel-ui/License.txt`.
- **Pixelarticons** (dependencia `pixelarticons`): MIT, © Gerrit Halfmann.
